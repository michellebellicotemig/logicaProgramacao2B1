﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Vetores
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Criar um vetor de 3 posições
            int[] vetNumeros = new int[3];

            //Random
            Random numAleatorio = new Random();

            //Preencher um vetor com números aleatórios
            for (int i = 0; i < 3; i++) //i=0,i=1,i=2
            {
                vetNumeros[i] = numAleatorio.Next(0, 100);
            }

            //Percorrer o vetor e mostrar mensagem
            for (int i = 0; i < 3; i++)
            {
                if (vetNumeros[i] > 30)
                {
                    MessageBox.Show("O valor da posição " + i + " = " + vetNumeros[i]);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Exercício 02 - Solução da fessora
            int [] vetNumeros = new int[8];

            //Random
            Random numAleatorio = new Random();

            //Preencher o vetor com valores aleatórios
            for(int i=0;i < 8; i++)
            {
                vetNumeros[i] = numAleatorio.Next(0,10);
            }

            //Variável auxiliar para maior valor
            int maiorValor = -1; 
            
            //Percorre e testa se é o maior que o valor da variável
            for (int i = 0;i < 8; i++)
            {
                if (vetNumeros[i] > maiorValor)
                {
                    maiorValor = vetNumeros[i];
                }
            }

            //Menor valor 
            MessageBox.Show("Maior valor = " + maiorValor);

        }
    }
}
