﻿namespace AppSimProva_Michelle_2B1
{
    partial class FrmQuestao03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlProdutos = new System.Windows.Forms.Panel();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.lblProduto3 = new System.Windows.Forms.Label();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.lblProduto2 = new System.Windows.Forms.Label();
            this.lblPreco1 = new System.Windows.Forms.Label();
            this.lblProduto1 = new System.Windows.Forms.Label();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.txtProduto3 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.txtProduto2 = new System.Windows.Forms.TextBox();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.txtProduto1 = new System.Windows.Forms.TextBox();
            this.pnlResultados = new System.Windows.Forms.Panel();
            this.lblParcela05r = new System.Windows.Forms.Label();
            this.lblParcela04r = new System.Windows.Forms.Label();
            this.lblParcela03r = new System.Windows.Forms.Label();
            this.lblParcela02r = new System.Windows.Forms.Label();
            this.lblParcela01r = new System.Windows.Forms.Label();
            this.lblParcela5 = new System.Windows.Forms.Label();
            this.lblParcela4 = new System.Windows.Forms.Label();
            this.lblParcela3 = new System.Windows.Forms.Label();
            this.lblParcela2 = new System.Windows.Forms.Label();
            this.lblParcela1 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTitulo.SuspendLayout();
            this.pnlProdutos.SuspendLayout();
            this.pnlResultados.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.pnlTitulo.Controls.Add(this.lblTitulo);
            this.pnlTitulo.Location = new System.Drawing.Point(-2, -12);
            this.pnlTitulo.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(798, 96);
            this.pnlTitulo.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.Black;
            this.lblTitulo.Location = new System.Drawing.Point(31, 35);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(319, 42);
            this.lblTitulo.TabIndex = 2;
            this.lblTitulo.Text = "LOJA DE GAMES";
            // 
            // pnlProdutos
            // 
            this.pnlProdutos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.pnlProdutos.Controls.Add(this.lblPreco3);
            this.pnlProdutos.Controls.Add(this.lblProduto3);
            this.pnlProdutos.Controls.Add(this.lblPreco2);
            this.pnlProdutos.Controls.Add(this.lblProduto2);
            this.pnlProdutos.Controls.Add(this.lblPreco1);
            this.pnlProdutos.Controls.Add(this.lblProduto1);
            this.pnlProdutos.Controls.Add(this.txtPreco3);
            this.pnlProdutos.Controls.Add(this.txtProduto3);
            this.pnlProdutos.Controls.Add(this.txtPreco2);
            this.pnlProdutos.Controls.Add(this.txtProduto2);
            this.pnlProdutos.Controls.Add(this.txtPreco1);
            this.pnlProdutos.Controls.Add(this.txtProduto1);
            this.pnlProdutos.Location = new System.Drawing.Point(12, 96);
            this.pnlProdutos.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.pnlProdutos.Name = "pnlProdutos";
            this.pnlProdutos.Size = new System.Drawing.Size(463, 280);
            this.pnlProdutos.TabIndex = 1;
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.ForeColor = System.Drawing.Color.White;
            this.lblPreco3.Location = new System.Drawing.Point(254, 190);
            this.lblPreco3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(68, 25);
            this.lblPreco3.TabIndex = 11;
            this.lblPreco3.Text = "Preço3";
            // 
            // lblProduto3
            // 
            this.lblProduto3.AutoSize = true;
            this.lblProduto3.ForeColor = System.Drawing.Color.White;
            this.lblProduto3.Location = new System.Drawing.Point(37, 190);
            this.lblProduto3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblProduto3.Name = "lblProduto3";
            this.lblProduto3.Size = new System.Drawing.Size(84, 25);
            this.lblProduto3.TabIndex = 5;
            this.lblProduto3.Text = "Produto3";
            this.lblProduto3.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.ForeColor = System.Drawing.Color.White;
            this.lblPreco2.Location = new System.Drawing.Point(255, 104);
            this.lblPreco2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(68, 25);
            this.lblPreco2.TabIndex = 10;
            this.lblPreco2.Text = "Preço2";
            // 
            // lblProduto2
            // 
            this.lblProduto2.AutoSize = true;
            this.lblProduto2.ForeColor = System.Drawing.Color.White;
            this.lblProduto2.Location = new System.Drawing.Point(36, 104);
            this.lblProduto2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblProduto2.Name = "lblProduto2";
            this.lblProduto2.Size = new System.Drawing.Size(84, 25);
            this.lblProduto2.TabIndex = 4;
            this.lblProduto2.Text = "Produto2";
            // 
            // lblPreco1
            // 
            this.lblPreco1.AutoSize = true;
            this.lblPreco1.ForeColor = System.Drawing.Color.White;
            this.lblPreco1.Location = new System.Drawing.Point(256, 23);
            this.lblPreco1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPreco1.Name = "lblPreco1";
            this.lblPreco1.Size = new System.Drawing.Size(68, 25);
            this.lblPreco1.TabIndex = 9;
            this.lblPreco1.Text = "Preço1";
            // 
            // lblProduto1
            // 
            this.lblProduto1.AutoSize = true;
            this.lblProduto1.ForeColor = System.Drawing.Color.White;
            this.lblProduto1.Location = new System.Drawing.Point(37, 23);
            this.lblProduto1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblProduto1.Name = "lblProduto1";
            this.lblProduto1.Size = new System.Drawing.Size(84, 25);
            this.lblProduto1.TabIndex = 3;
            this.lblProduto1.Text = "Produto1";
            // 
            // txtPreco3
            // 
            this.txtPreco3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.txtPreco3.Location = new System.Drawing.Point(259, 221);
            this.txtPreco3.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(164, 32);
            this.txtPreco3.TabIndex = 8;
            // 
            // txtProduto3
            // 
            this.txtProduto3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.txtProduto3.Location = new System.Drawing.Point(41, 221);
            this.txtProduto3.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtProduto3.Name = "txtProduto3";
            this.txtProduto3.Size = new System.Drawing.Size(164, 32);
            this.txtProduto3.TabIndex = 2;
            this.txtProduto3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // txtPreco2
            // 
            this.txtPreco2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.txtPreco2.Location = new System.Drawing.Point(259, 135);
            this.txtPreco2.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(164, 32);
            this.txtPreco2.TabIndex = 7;
            // 
            // txtProduto2
            // 
            this.txtProduto2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.txtProduto2.Location = new System.Drawing.Point(41, 135);
            this.txtProduto2.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtProduto2.Name = "txtProduto2";
            this.txtProduto2.Size = new System.Drawing.Size(164, 32);
            this.txtProduto2.TabIndex = 1;
            // 
            // txtPreco1
            // 
            this.txtPreco1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.txtPreco1.Location = new System.Drawing.Point(259, 54);
            this.txtPreco1.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(164, 32);
            this.txtPreco1.TabIndex = 6;
            // 
            // txtProduto1
            // 
            this.txtProduto1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.txtProduto1.Location = new System.Drawing.Point(41, 54);
            this.txtProduto1.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtProduto1.Name = "txtProduto1";
            this.txtProduto1.Size = new System.Drawing.Size(164, 32);
            this.txtProduto1.TabIndex = 0;
            // 
            // pnlResultados
            // 
            this.pnlResultados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.pnlResultados.Controls.Add(this.lblParcela05r);
            this.pnlResultados.Controls.Add(this.lblParcela04r);
            this.pnlResultados.Controls.Add(this.lblParcela03r);
            this.pnlResultados.Controls.Add(this.lblParcela02r);
            this.pnlResultados.Controls.Add(this.lblParcela01r);
            this.pnlResultados.Controls.Add(this.lblParcela5);
            this.pnlResultados.Controls.Add(this.lblParcela4);
            this.pnlResultados.Controls.Add(this.lblParcela3);
            this.pnlResultados.Controls.Add(this.lblParcela2);
            this.pnlResultados.Controls.Add(this.lblParcela1);
            this.pnlResultados.Location = new System.Drawing.Point(495, 96);
            this.pnlResultados.Name = "pnlResultados";
            this.pnlResultados.Size = new System.Drawing.Size(285, 280);
            this.pnlResultados.TabIndex = 2;
            // 
            // lblParcela05r
            // 
            this.lblParcela05r.AutoSize = true;
            this.lblParcela05r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela05r.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela05r.Location = new System.Drawing.Point(169, 197);
            this.lblParcela05r.Name = "lblParcela05r";
            this.lblParcela05r.Size = new System.Drawing.Size(18, 25);
            this.lblParcela05r.TabIndex = 9;
            this.lblParcela05r.Text = "-";
            // 
            // lblParcela04r
            // 
            this.lblParcela04r.AutoSize = true;
            this.lblParcela04r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela04r.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela04r.Location = new System.Drawing.Point(169, 163);
            this.lblParcela04r.Name = "lblParcela04r";
            this.lblParcela04r.Size = new System.Drawing.Size(18, 25);
            this.lblParcela04r.TabIndex = 8;
            this.lblParcela04r.Text = "-";
            // 
            // lblParcela03r
            // 
            this.lblParcela03r.AutoSize = true;
            this.lblParcela03r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela03r.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela03r.Location = new System.Drawing.Point(169, 126);
            this.lblParcela03r.Name = "lblParcela03r";
            this.lblParcela03r.Size = new System.Drawing.Size(18, 25);
            this.lblParcela03r.TabIndex = 7;
            this.lblParcela03r.Text = "-";
            // 
            // lblParcela02r
            // 
            this.lblParcela02r.AutoSize = true;
            this.lblParcela02r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela02r.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela02r.Location = new System.Drawing.Point(169, 92);
            this.lblParcela02r.Name = "lblParcela02r";
            this.lblParcela02r.Size = new System.Drawing.Size(18, 25);
            this.lblParcela02r.TabIndex = 6;
            this.lblParcela02r.Text = "-";
            // 
            // lblParcela01r
            // 
            this.lblParcela01r.AutoSize = true;
            this.lblParcela01r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela01r.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela01r.Location = new System.Drawing.Point(169, 55);
            this.lblParcela01r.Name = "lblParcela01r";
            this.lblParcela01r.Size = new System.Drawing.Size(18, 25);
            this.lblParcela01r.TabIndex = 5;
            this.lblParcela01r.Text = "-";
            // 
            // lblParcela5
            // 
            this.lblParcela5.AutoSize = true;
            this.lblParcela5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela5.Location = new System.Drawing.Point(18, 197);
            this.lblParcela5.Name = "lblParcela5";
            this.lblParcela5.Size = new System.Drawing.Size(140, 25);
            this.lblParcela5.TabIndex = 4;
            this.lblParcela5.Text = "05 parcelas de: ";
            // 
            // lblParcela4
            // 
            this.lblParcela4.AutoSize = true;
            this.lblParcela4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela4.Location = new System.Drawing.Point(18, 163);
            this.lblParcela4.Name = "lblParcela4";
            this.lblParcela4.Size = new System.Drawing.Size(140, 25);
            this.lblParcela4.TabIndex = 3;
            this.lblParcela4.Text = "04 parcelas de: ";
            // 
            // lblParcela3
            // 
            this.lblParcela3.AutoSize = true;
            this.lblParcela3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela3.Location = new System.Drawing.Point(18, 127);
            this.lblParcela3.Name = "lblParcela3";
            this.lblParcela3.Size = new System.Drawing.Size(140, 25);
            this.lblParcela3.TabIndex = 2;
            this.lblParcela3.Text = "03 parcelas de: ";
            // 
            // lblParcela2
            // 
            this.lblParcela2.AutoSize = true;
            this.lblParcela2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela2.Location = new System.Drawing.Point(18, 92);
            this.lblParcela2.Name = "lblParcela2";
            this.lblParcela2.Size = new System.Drawing.Size(140, 25);
            this.lblParcela2.TabIndex = 1;
            this.lblParcela2.Text = "02 parcelas de: ";
            // 
            // lblParcela1
            // 
            this.lblParcela1.AutoSize = true;
            this.lblParcela1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.lblParcela1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblParcela1.Location = new System.Drawing.Point(18, 57);
            this.lblParcela1.Name = "lblParcela1";
            this.lblParcela1.Size = new System.Drawing.Size(131, 25);
            this.lblParcela1.TabIndex = 0;
            this.lblParcela1.Text = "01 parcela de: ";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(12, 385);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(768, 51);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmQuestao03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(48)))), ((int)(((byte)(71)))));
            this.ClientSize = new System.Drawing.Size(792, 448);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.pnlResultados);
            this.Controls.Add(this.pnlProdutos);
            this.Controls.Add(this.pnlTitulo);
            this.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "FrmQuestao03";
            this.Text = "FrmQuestao03";
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.pnlProdutos.ResumeLayout(false);
            this.pnlProdutos.PerformLayout();
            this.pnlResultados.ResumeLayout(false);
            this.pnlResultados.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlProdutos;
        private System.Windows.Forms.Label lblPreco3;
        private System.Windows.Forms.Label lblProduto3;
        private System.Windows.Forms.Label lblPreco2;
        private System.Windows.Forms.Label lblProduto2;
        private System.Windows.Forms.Label lblPreco1;
        private System.Windows.Forms.Label lblProduto1;
        private System.Windows.Forms.TextBox txtPreco3;
        private System.Windows.Forms.TextBox txtProduto3;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.TextBox txtProduto2;
        private System.Windows.Forms.TextBox txtPreco1;
        private System.Windows.Forms.TextBox txtProduto1;
        private System.Windows.Forms.Panel pnlResultados;
        private System.Windows.Forms.Label lblParcela05r;
        private System.Windows.Forms.Label lblParcela04r;
        private System.Windows.Forms.Label lblParcela03r;
        private System.Windows.Forms.Label lblParcela02r;
        private System.Windows.Forms.Label lblParcela01r;
        private System.Windows.Forms.Label lblParcela5;
        private System.Windows.Forms.Label lblParcela4;
        private System.Windows.Forms.Label lblParcela3;
        private System.Windows.Forms.Label lblParcela2;
        private System.Windows.Forms.Label lblParcela1;
        private System.Windows.Forms.Button btnCalcular;
    }
}